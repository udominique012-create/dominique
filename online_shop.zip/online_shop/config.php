<?php
/* ============================================================
   FRANCOIS SHOES & CLOTHES STORE — Configuration
   ============================================================ */

/* ===== Database ===== */
const DB_HOST = 'localhost';
const DB_NAME = 'dnazcgrz_product';
const DB_USER = 'dnazcgrz_francois';
const DB_PASS = 'ZYD^fl$fjTPg1$1q';

/* ===== Delivery ===== */
// ⚠️ SHYIRA 0 kugira ngo nta mafaranga yongerwa ku giciro cy'ibicuruzwa
const DELIVERY          = 0;
const FREE_OVER         = 0;
const TRANSPORT_OUTSIDE = 0;

/* ===== Uploads ===== */
const MAX_UPLOAD_MB = 60;

/* ===== Security ===== */
// ⚠️ HINDURA IYI KUBA true N IBA URUBUGA RUKORESHAnye HTTPS
const COOKIE_SECURE = false;
// ⚠️ HINDURA IYI KUBA true MBERE YO KUPAKIRA KUGIRA NGO UREBE AMAKOSA
const DEBUG         = false;
const SESSION_IDLE  = 1800;
const SESSION_MAX   = 28800;

/* ===== Email (SMTP) ===== */
// ⚠️ UZUZA IZI NKURU KURI HOSTING YAWE NYAYO
const MAIL_FROM      = 'niyogisubizofrancois7@gmail.com';
const MAIL_FROM_NAME = 'FRANCOIS STORE';
const SMTP_HOST      = 'mail.francoisonlineshop.com';
const SMTP_PORT      = 587;
const SMTP_USER      = 'niyogisubizofrancois7@gmail.com';
const SMTP_PASS      = 'm.T)V2Z-EcV51A}i';
const SMTP_SECURE    = 'tls';

/* ===== SMS ===== */
const SMS_USER = 'sandbox';
const SMS_KEY  = 'SMS_API_KEY_YAWE';
const SMS_FROM = 'FRANCOIS';
const SMS_URL  = 'https://api.africastalking.com/version1/messaging';

/* ===== Urubuga ===== */
// ⚠️ HINDURA IYI KUBA DOMAIN YAWE NYAYO
const SITE_URL  = 'https://francoisonlineshop.com';
const RESET_TTL = 1800;
const OTP_TTL   = 600;
const OTP_MAX_TRY = 5;

/* ===== Admin ===== */
if (!defined('ADMIN_PHONE')) {
    define('ADMIN_PHONE','+250784292599');
}