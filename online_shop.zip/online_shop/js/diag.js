(function () {
  var out = document.getElementById("out"), info = document.getElementById("info");
  var BASE = location.pathname.replace(/diag\.html$/, "").replace(/\/?$/, "/");
  function add(ok, name, detail, hint) {
    var d = document.createElement("div"); d.className = "r " + (ok ? "ok" : "bad");
    var b = document.createElement("b"); b.textContent = (ok ? "✓ " : "✗ ") + name; d.appendChild(b);
    var s = document.createElement("small"); s.textContent = detail; d.appendChild(s);
    if (hint) { var h = document.createElement("div"); h.className = "hint"; h.textContent = hint; d.appendChild(h); }
    out.appendChild(d);
  }
  var p = document.createElement("p"); p.textContent = "Aderesi: " + location.href + "  ·  inzira y'ibanze: " + BASE; info.appendChild(p);
  if (/\/python\//i.test(location.pathname)) add(false, "Ufunguye verisiyo ya PYTHON", location.pathname, "Kuri XAMPP (Apache + PHP) koresha ububiko php/: shyira ibiri muri php/ byose muri C:\\xampp\\htdocs\\online_shop\\, hanyuma ufungure http://localhost/online_shop/diag.html");
  if (location.protocol === "file:") {
    add(false, "Wafunguye dosiye uyikanze (file://)", location.href, "Ugomba gufungura urubuga unyuze kuri seriveri: http://localhost/… (Apache ya XAMPP ikorwa). Gufungura index.html uyikanze ntibikora.");
    return;
  }
  var checks = [["css/styles.css", "css"], ["css/admin.css", "css"], ["js/i18n.js", "js"], ["js/app.js", "js"], ["js/admin.js", "js"], ["api/", "json"], ["api/products", "json"], ["api/announcements", "json"], ["api/admin/me", "json"]];
  checks.forEach(function (c) {
    fetch(BASE + c[0], { cache: "no-store" }).then(function (r) {
      return r.text().then(function (t) {
        var ct = r.headers.get("content-type") || "?", ok = r.ok, hint = "", snippet = t.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 160);
        if (c[1] === "json") {
          try { var j = JSON.parse(t); if (j && j.error) { ok = false; hint = "API yasubije ikosa: " + (j.detail || j.error) + (j.error === "server" ? " — shyira DEBUG = true muri config.php urebe ibisobanuro, kandi ukore check.php." : ""); } }
          catch (e) { ok = false; hint = r.status === 404 ? "API ntiboneka (404). .htaccess ntikora: reba ko mod_rewrite ifunguye muri httpd.conf na AllowOverride All, ukongere utangize Apache; reba ko .htaccess iri mu gafolder. (Iduka na admin birakora ubwabyo bikoresha api.php?route=, ariko fungura admin ukoresheje /admin.html.)" : "API ntisubiza JSON. PHP ishobora kuba yahuye n'ikosa: reba C:\\xampp\\apache\\logs\\error.log cyangwa shyira DEBUG = true muri config.php."; }
        } else if (ok && /^\s*</.test(t)) { ok = false; hint = "Iyi dosiye yasubije HTML aho kuba " + c[1].toUpperCase() + " — inzira si yo cyangwa dosiye ntiyaboneka."; }
        else if (!ok) hint = "HTTP " + r.status + " — dosiye ntiyaboneka. Reba ko wayishyize muri gafolder imwe na index.html.";
        add(ok, c[0], "HTTP " + r.status + " · " + ct + (ok ? "" : " · " + snippet), hint);
      });
    }).catch(function (e) { add(false, c[0], String(e), "Seriveri ntisubiza. Reba ko Apache ikora muri XAMPP."); });
  });
})();
