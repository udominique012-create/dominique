<?php
/* ============================================================
   notify.php — Kohereza email (SMTP) na SMS (Africa's Talking)
   Koresha: require_once __DIR__.'/config.php'; require_once __DIR__.'/notify.php';
   Buri function isubiza [bool $ok, string $detail]
   ============================================================ */
if (!defined('SMTP_HOST')) { http_response_code(403); exit; }

/* +2507XXXXXXXX — yemera 07..., 2507..., +2507... */
function normalize_phone(string $p): string {
    $d = preg_replace('/\D+/', '', $p);
    if (strpos($d, '250') === 0) return '+' . $d;
    if (strpos($d, '0') === 0)   return '+250' . substr($d, 1);
    if (strlen($d) === 9)        return '+250' . $d;
    return '+' . $d;
}
/* Gereranya telefoni mu buryo bwose bushoboka (kubona konti muri DB) */
function phone_variants(string $p): array {
    $n = normalize_phone($p);
    $local = '0' . substr($n, 4);
    return array_values(array_unique([$p, $n, substr($n, 1), $local]));
}

/* ---------- SMS ---------- */
function sms_send(string $to, string $text): array {
    $to = normalize_phone($to);
    $sandbox = (SMS_USER === 'sandbox');
    $url = $sandbox ? 'https://api.sandbox.africastalking.com/version1/messaging' : SMS_URL;
    $post = ['username' => SMS_USER, 'to' => $to, 'message' => $text];
    if (!$sandbox && SMS_FROM !== '') $post['from'] = SMS_FROM;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($post),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'apiKey: ' . SMS_KEY,
                               'Content-Type: application/x-www-form-urlencoded'],
    ]);
    $res = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res === false) { error_log("SMS curl: $err"); return [false, "SMS: $err"]; }
    $j = json_decode($res, true);
    $r = $j['SMSMessageData']['Recipients'][0] ?? null;
    $ok = $code >= 200 && $code < 300 && $r && stripos($r['status'] ?? '', 'Success') !== false;
    if (!$ok) error_log("SMS fail HTTP $code: $res");
    return [$ok, $ok ? 'ok' : 'SMS: ' . ($r['status'] ?? "HTTP $code") .
        ($sandbox ? ' (sandbox ntiyohereza ku telefoni nyayo — koresha konti ya production)' : '')];
}

/* ---------- SMTP (nta PHPMailer ikenewe) ---------- */
function smtp_send(string $to, string $subject, string $html): array {
    $secure = strtolower(SMTP_SECURE);
    $host = ($secure === 'ssl' ? 'ssl://' : '') . SMTP_HOST;
    $fp = @stream_socket_client("$host:" . SMTP_PORT, $en, $es, 20);
    if (!$fp) { error_log("SMTP connect: $es"); return [false, "SMTP: ntibasha guhuza ($es)"]; }
    stream_set_timeout($fp, 20);
    $read = function () use ($fp) {
        $o = '';
        while (($l = fgets($fp, 515)) !== false) { $o .= $l; if (isset($l[3]) && $l[3] === ' ') break; }
        return $o;
    };
    $cmd = function (string $c, string $expect) use ($fp, $read) {
        fwrite($fp, $c . "\r\n"); $r = $read();
        return strpos($r, $expect) === 0 ? [true, $r] : [false, $r];
    };
    $fail = function (string $m) use ($fp) { @fwrite($fp, "QUIT\r\n"); fclose($fp); error_log("SMTP: $m"); return [false, "SMTP: " . trim($m)]; };

    $r = $read(); if (strpos($r, '220') !== 0) return $fail($r);
    $ehlo = parse_url(SITE_URL, PHP_URL_HOST) ?: 'localhost';
    [$ok, $r] = $cmd("EHLO $ehlo", '250'); if (!$ok) return $fail($r);
    if ($secure === 'tls') {
        [$ok, $r] = $cmd('STARTTLS', '220'); if (!$ok) return $fail($r);
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) return $fail('TLS ntibashije');
        [$ok, $r] = $cmd("EHLO $ehlo", '250'); if (!$ok) return $fail($r);
    }
    [$ok, $r] = $cmd('AUTH LOGIN', '334');                       if (!$ok) return $fail($r);
    [$ok, $r] = $cmd(base64_encode(SMTP_USER), '334');           if (!$ok) return $fail($r);
    [$ok, $r] = $cmd(base64_encode(SMTP_PASS), '235');           if (!$ok) return $fail('Izina/ijambobanga rya SMTP si byo: ' . $r);
    [$ok, $r] = $cmd('MAIL FROM:<' . MAIL_FROM . '>', '250');    if (!$ok) return $fail($r);
    [$ok, $r] = $cmd("RCPT TO:<$to>", '250');                    if (!$ok) return $fail($r);
    [$ok, $r] = $cmd('DATA', '354');                             if (!$ok) return $fail($r);

    $h  = 'From: =?UTF-8?B?' . base64_encode(MAIL_FROM_NAME) . '?= <' . MAIL_FROM . ">\r\n";
    $h .= "To: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
    $h .= "Date: " . date('r') . "\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $body = chunk_split(base64_encode($html));
    fwrite($fp, $h . $body . "\r\n.\r\n");
    $r = $read(); if (strpos($r, '250') !== 0) return $fail($r);
    fwrite($fp, "QUIT\r\n"); fclose($fp);
    return [true, 'ok'];
}

/* ---------- Ibyoroshye byo gukoresha muri api.php ---------- */
function send_reset_otp_sms(string $phone, string $otp): array {
    return sms_send($phone, "FRANCOIS STORE: kode yawe yo guhindura ijambobanga ni $otp. Irarangira nyuma y'iminota " . intdiv(OTP_TTL, 60) . ". Ntuyisangize undi muntu.");
}
function send_reset_link_email(string $email, string $token): array {
    $link = rtrim(SITE_URL, '/') . '/admin.html?reset=' . urlencode($token);
    $html = '<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto">'
          . '<h2>FRANCOIS STORE — Guhindura ijambobanga</h2>'
          . '<p>Kanda hano kugira ngo ushyireho ijambobanga rishya (rimara iminota ' . intdiv(RESET_TTL, 60) . '):</p>'
          . '<p><a href="' . htmlspecialchars($link) . '" style="background:#0F5C4D;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none">Hindura ijambobanga</a></p>'
          . '<p style="color:#666;font-size:12px">Niba utabisabye, ntugire icyo ukora kuri iyi email.</p></div>';
    return smtp_send($email, 'Guhindura ijambobanga — FRANCOIS STORE', $html);
}
