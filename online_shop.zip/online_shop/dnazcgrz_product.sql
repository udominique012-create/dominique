-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 03, 2026 at 07:16 AM
-- Server version: 10.11.19-MariaDB-cll-lve
-- PHP Version: 8.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dnazcgrz_product`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `pass` varchar(255) NOT NULL,
  `recovery` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `phone`, `pass`, `recovery`) VALUES
(4, 'Francois', 'niyogisubizofrancois7@gmail.com', '0784292599', '$2y$10$ZBe8LMtYt9wro.IVn9Dd2es9/Wyk9R6AZJ4CN7QpcrxwyPO2hCoqu', '$2y$10$hxsoanKB3kQ/RsCwV7iRY..xbUcnnOzBixnQIMvrKGWOd8v1fZjLO');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `body` varchar(255) NOT NULL,
  `active` tinyint(4) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `body`, `active`, `created_at`) VALUES
(3, 'BONUS: air max iri kugura 20000', 0, '2026-10-20 20:12:44'),
(4, 'samba yari 30000 ubu ni 25000', 0, '2026-10-30 19:15:28');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(11) NOT NULL,
  `token` char(32) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `product` varchar(150) DEFAULT NULL,
  `admin_unread` int(11) DEFAULT 0,
  `last_msg_at` datetime DEFAULT current_timestamp(),
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `token`, `name`, `phone`, `product`, `admin_unread`, `last_msg_at`, `created_at`) VALUES
(6, '16b5de63f271af34afde173332066bc6', 'Mucyo claude', '0783289168', 'Sheos', 0, '2026-10-31 13:44:41', '2026-10-31 05:22:35'),
(7, 'ce92d753ffb941ad4d4a94e9d3a44de2', 'Theoneste', '0789479625', '', 0, '2026-10-31 19:22:18', '2026-10-31 19:21:54'),
(8, '996783b2d34215cf5122a1fc126d064a', 'Elie', '0798015535', 'van khalifa (Size 42) (black)', 0, '2026-10-31 19:40:25', '2026-10-31 19:36:56'),
(9, '4f9bc3a2ab1b5e52efd54fdd573b7f49', 'Would you reduce price for this', '', 'Travis Scott', 0, '2026-11-01 16:41:52', '2026-10-31 19:43:25'),
(10, '7f1715f2a677434d460432f7c1e9f521', 'Hghu', '08855', 'Ggyu8', 0, '2026-11-01 16:42:17', '2026-10-31 20:22:08'),
(11, '7be362f91931f621e57359f1b0e47977', 'Ishimwe', '0798644462', 'yzeey (black)', 0, '2026-11-01 16:42:37', '2026-10-31 20:43:46'),
(12, '756850a77a566b22103ad7975d407c60', 'Patrick', '0785501975', 'Shoes', 0, '2026-11-01 16:43:06', '2026-10-31 21:50:03'),
(13, '075a94751d52f7fe463272e729038b73', 'Chris', '', 'mens leather shoes (Size 44)', 0, '2026-11-01 16:43:31', '2026-10-31 22:36:33'),
(14, 'df5776b010f909970800b7e89f24e144', 'Sivilize', '0784666670', 'mens leather shoes (Size 41)', 0, '2026-11-02 07:31:32', '2026-11-01 07:30:25'),
(15, '756421f5e07e924c50c153326453b47c', 'Maubert', '', '', 0, '2026-11-02 13:58:42', '2026-11-02 13:58:42'),
(16, '1e839a203bc268f9948f9019ae134e84', 'Costa', '0781686035', 'Shoes', 0, '2026-11-03 06:28:42', '2026-11-02 16:26:59'),
(17, '5e8811868e9fbf430d441e4da72217b8', 'Xavier Dominique Uwumuremyi', '0789230021', 'air force (Size 44) (chocolate)', 0, '2026-11-03 06:54:12', '2026-11-03 06:54:11');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `ts` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `sender` char(1) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `chat_id`, `sender`, `body`, `image`, `created_at`) VALUES
(26, 5, 'a', 'iyo irahari', NULL, '2026-10-30 19:20:29'),
(27, 6, 'c', 'Ndashaka kumenya byinshi kuri: Sheos', NULL, '2026-10-31 05:22:35'),
(28, 6, 'a', 'ushak imeze gutex', NULL, '2026-10-31 13:44:41'),
(29, 5, 'a', '', '/uploads/1793464395-ed06f755210e.png', '2026-10-31 16:33:16'),
(30, 7, 'c', 'Nyeneye inkweto bro', NULL, '2026-10-31 19:22:18'),
(31, 8, 'c', 'Ndashaka kumenya byinshi kuri: van khalifa (Size 42) (black)', NULL, '2026-10-31 19:36:56'),
(32, 8, 'c', 'Hey', NULL, '2026-10-31 19:37:14'),
(33, 8, 'a', 'irahari', NULL, '2026-10-31 19:38:31'),
(34, 8, 'c', 'Yohereze ikirehe', NULL, '2026-10-31 19:40:25'),
(35, 9, 'c', 'Ndashaka kumenya byinshi kuri: Travis Scott', NULL, '2026-10-31 19:43:25'),
(36, 9, 'c', 'Waga anll', NULL, '2026-10-31 19:43:40'),
(37, 10, 'c', 'Ndashaka kumenya byinshi kuri: Ggyu8', NULL, '2026-10-31 20:22:08'),
(38, 11, 'c', 'Ndashaka kumenya byinshi kuri: yzeey (black)', NULL, '2026-10-31 20:43:46'),
(39, 12, 'c', 'Ndashaka kumenya byinshi kuri: Shoes', NULL, '2026-10-31 21:50:03'),
(40, 12, 'c', 'Ufite timba', NULL, '2026-10-31 21:50:19'),
(41, 13, 'c', 'Ndashaka kumenya byinshi kuri: mens leather shoes (Size 44)', NULL, '2026-10-31 22:36:33'),
(42, 14, 'c', 'Ndashaka kumenya byinshi kuri: mens leather shoes (Size 41)', NULL, '2026-11-01 07:30:25'),
(43, 14, 'c', 'Iyi nkweto c ko nyishaka arko chocolate yayo', NULL, '2026-11-01 07:31:06'),
(44, 9, 'a', 'ushak size kangahex', NULL, '2026-11-01 16:41:52'),
(45, 10, 'a', 'which one', NULL, '2026-11-01 16:42:17'),
(46, 11, 'a', 'ushak size kangahex', NULL, '2026-11-01 16:42:37'),
(47, 12, 'a', 'timberland zirahari isa gutex', NULL, '2026-11-01 16:43:06'),
(48, 13, 'a', 'ushak isa gutex', NULL, '2026-11-01 16:43:31'),
(49, 14, 'a', 'iyihe x Ushak', NULL, '2026-11-01 16:44:01'),
(50, 14, 'a', 'uyishaka ryarix', NULL, '2026-11-02 07:31:32'),
(51, 16, 'c', 'Ndashaka kumenya byinshi kuri: Shoes', NULL, '2026-11-02 16:26:59'),
(52, 16, 'a', 'hello', NULL, '2026-11-03 06:28:42'),
(53, 17, 'c', 'Ndashaka kumenya byinshi kuri: air force (Size 44) (chocolate)', NULL, '2026-11-03 06:54:11'),
(54, 17, 'c', '', '/uploads/1793468838-aa28d1dab254.png', '2026-11-03 06:54:12');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `items` text DEFAULT NULL,
  `subtotal` int(11) NOT NULL DEFAULT 0,
  `shipping` int(11) NOT NULL DEFAULT 0,
  `total` int(11) DEFAULT NULL,
  `momo_txn` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'bishya',
  `pay_status` varchar(12) DEFAULT 'itegereje',
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `phone`, `address`, `items`, `subtotal`, `shipping`, `total`, `momo_txn`, `status`, `pay_status`, `paid_at`, `created_at`) VALUES
(21, 'Kwizera', '0782172572', 'Gisozi', '[{\"name\":\"mens leather shoes\",\"size\":\"42\",\"color\":\"Black and white\",\"qty\":1,\"price\":45000}]', 45000, 0, 45000, '', 'bishya', 'itegereje', NULL, '2026-10-31 21:04:34'),
(22, 'gahigi', '+250792043227', 'nyarugenge', '[{\"name\":\"air force\",\"size\":\"38\",\"color\":\"white\",\"qty\":1,\"price\":28000}]', 28000, 0, 28000, '', 'bishya', 'itegereje', NULL, '2026-11-01 07:11:47');

-- --------------------------------------------------------

--
-- Table structure for table `otp_codes`
--

CREATE TABLE `otp_codes` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `code_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(4) DEFAULT 0,
  `used` tinyint(4) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp_codes`
--

INSERT INTO `otp_codes` (`id`, `admin_id`, `code_hash`, `expires_at`, `attempts`, `used`, `created_at`) VALUES
(2, 4, 'd7a774f0033008e5f6aade3c5b90fd42e222f18c941e869e6e3c886f3cb8f052', '2026-10-30 19:07:16', 0, 0, '2026-10-30 18:57:16'),
(3, 4, 'da52bfc0f1447196778dd38b07aa0c18f53fdececd11c5a3c17e618aef4d6e8d', '2026-10-30 19:08:45', 0, 0, '2026-10-30 18:58:45');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `channel` char(1) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(4) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `admin_id`, `token_hash`, `channel`, `expires_at`, `used`, `created_at`) VALUES
(1, 4, '8280baa175924d8cdbe170549a2a3ce7e951c984e9bb11696e51a486a3581fed', 'e', '2026-10-30 19:30:07', 0, '2026-10-30 19:00:07');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `cat` varchar(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `color` varchar(9) DEFAULT '#D6246E',
  `bg` varchar(9) DEFAULT '#FFE3EF',
  `price` int(11) NOT NULL,
  `old_price` int(11) DEFAULT NULL,
  `sizes` varchar(100) NOT NULL,
  `variants` varchar(255) DEFAULT NULL,
  `badge` varchar(30) DEFAULT '',
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `active` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `cat`, `type`, `color`, `bg`, `price`, `old_price`, `sizes`, `variants`, `badge`, `image`, `video`, `active`) VALUES
(20, 'Ascas', 'Inkweto', 'shoe', '#d6246e', '#00ff00', 35000, 40000, '37, 38,39,40,41,42,43,44,45', 'black,white', 'NEW', '/uploads/1793387401-c258bd59b075.png', NULL, 1),
(21, 'Jordan1 SB dunk', 'Inkweto', 'shoe', '#d6246e', '#ffffff', 28000, 30000, '37, 38,39,40,41,42,43,44,45', 'chocolate, black and white', 'NEW', '/uploads/1793390312-4eb1858008dc.png', NULL, 1),
(22, 'new balance 1000', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 35000, NULL, '40,41,42,43,44,45', 'grey , black, green and white', 'NEW', '/uploads/1793390194-732280a0f814.png', NULL, 1),
(23, 'Travis Scott', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 32000, 35000, '39,40,41,42,43,44,45', 'chocolate, black , grey,', 'NEW', '/uploads/1793390107-22b70cb03680.png', NULL, 1),
(24, 'BOSS', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 45000, 50000, '40,41,42,43,44,45', 'black&white ,black,white, chocolate', 'NEW', '/uploads/1793390528-1cc0a7a71ee2.png', NULL, 1),
(25, 'F50', 'Inkweto', 'shoe', '#d6246e', '#d16060', 50000, NULL, '40,41,42,43,44,45', 'black, green,white, blue', 'NEW', '/uploads/1793390926-513d675c8900.png', NULL, 1),
(29, 'new balance', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 32000, 35000, '37, 38,39,40,41,42,43,44,45', 'white and red, white and pink, pink, black, black and white', 'NEW', '/uploads/1793458309-b8f1a14111c9.jpg', NULL, 1),
(30, 'compus', 'Inkweto', 'shoe', '#d6246e', '#302d29', 32000, 35000, '37, 38,39,40,41,42,43,44', 'black, Pink, black and white', '', '/uploads/1793458513-d85ae0e60bae.jpg', NULL, 1),
(31, 'air force', 'Inkweto', 'shoe', '#d6246e', '#ff00ff', 30000, 32000, '37, 38,39,40,41,42,43,44,45', 'pink and white', 'NEW', '/uploads/1793458774-37aac393106a.jpg', NULL, 1),
(32, 'air force', 'Inkweto', 'shoe', '#ff00ff', '#ffe3ef', 28000, 30000, '37, 38,39,40,41,42,43,44,45', 'black,white', '', '/uploads/1793458848-3f864d6ed76d.jpg', NULL, 1),
(34, 'Adidas Adizero', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 37000, 40000, '40,41,42,43,44,45', 'black,white , grey', 'NEW', '/uploads/1793460161-b292299c9968.jpg', NULL, 1),
(36, 'Nike Air max', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 37000, NULL, '39,40,41,42,43,44,45', 'grey and black', 'NEW', '/uploads/1793460486-c69a154172ea.jpg', NULL, 1),
(37, 'Crocs Lite ride', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 20000, 23000, '36,37, 38,39,40,41,42,43,44,45', 'chocolate, black and green, blue', 'NEW', '/uploads/1793460660-9f2b5c471315.jpg', NULL, 1),
(38, 'mens leather shoes', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 45000, 50000, '40,41,42,43,44,45', 'chocolate, black and white', 'NEW', '/uploads/1793464160-6af57d902bc7.png', NULL, 1),
(39, 'air force', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 28000, 30000, '39_45', 'white and green', '', '/uploads/1793466616-3e2772d89936.png', NULL, 1),
(40, 'mens casual', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 45000, 50000, '40,41,42,43,44,45', 'black and white, chocolate, yellow and white', 'NEW', '/uploads/1793466724-078c021cd439.png', NULL, 1),
(41, 'mens leather shoes', 'Inkweto', 'shoe', '#d6246e', '#ff00ff', 45000, 50000, '40_45', 'black, black and white, grey', '', '/uploads/1793466814-d9cfc28d4b83.png', NULL, 1),
(42, 'mens casual shoes', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 60000, 65000, '40,41,42,43,44,45', 'black chocolate', 'NEW', '/uploads/1793466925-05078064ce14.png', NULL, 1),
(43, 'mens leather shoes', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 50000, 55000, '38,39,40,41,42,43,44,45', 'chocolate, black', 'NEW', '/uploads/1793466997-84239369fa9a.png', NULL, 1),
(44, 'puma speedcat', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 35000, 37000, '36,37, 38,39,40,41,42,43,44,45', 'black and pink, pink , Red, white, grey', 'NEW', '/uploads/1793467178-4b9fd20e0de9.png', NULL, 1),
(45, 'mens leather shoes', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 45000, 50000, '40,41,42,43,44,45', 'Black and white, grey', 'NEW', '/uploads/1793467259-a92cc9fc4955.png', NULL, 1),
(46, 'mens leather shoes', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 40000, 45000, '39,40,41,42,43,44,45', 'chocolate, black and gray', 'NEW', '/uploads/1793467332-bc1a3d16b49b.png', NULL, 1),
(47, 'Converse', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 27000, 30000, '37, 38,39,40,41,42,43,44,45', 'black and white, white, yellow', '', '/uploads/1793467442-26689cbd700c.png', NULL, 1),
(48, 'Nike zoom', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 27000, 30000, '40,41,42,43,44,45', 'black, grey', '', '/uploads/1793468307-4421cdefe589.png', NULL, 1),
(49, 'Nike zoom', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 32000, 35000, '40,41,42,43,44,45', 'black,white', 'NEW', '/uploads/1793468420-473bd50d3831.png', NULL, 1),
(50, 'Jordan 3', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 35000, 40000, '37, 38,39,40,41,42,43,44,45', 'black, white, green', 'NEW', '/uploads/1793468502-7a750ef7f444.png', NULL, 1),
(51, 'yzeey', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 25000, 27000, '36,37, 38,39,40,41,42,43,44,45', 'black', '', '/uploads/1793468578-b4a21af45e05.png', NULL, 1),
(53, 'van khalifa', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 35000, 37000, '37, 38,39,40,41,42,43,44,45', 'black, black and white', '', '/uploads/1793468751-076e9b536d4d.png', NULL, 1),
(54, 'air force', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 32000, 35000, '38,39,40,41,42,43,44,45', 'red , black green, chocolate', 'NEW', '/uploads/1793468838-aa28d1dab254.png', NULL, 1),
(55, 'mens leather shoes', 'Inkweto', 'shoe', '#d6246e', '#ffe3ef', 45000, 50000, '39,40,41,42,43,44,45', 'black, grey,chocolate', 'NEW', '/uploads/1793468931-abb03a8b7a3a.png', NULL, 1),
(56, 'women style', 'Imyenda', 'dress', '#d6246e', '#ffe3ef', 45000, NULL, 'medium, large', 'black,white', 'NEW', '/uploads/1793607555-7a40dc001c99.png', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `updated_at`) VALUES
(2, 'about_hours', 'everyday', '2026-10-30 20:16:16'),
(5, 'about_text', 'bout Us\n\n**Welcome to FRANCOIS SHOES & CLOTHES STORE — Style for Every You!**\n\nAt FRANCOIS SHOES & CLOTHES STORE, we believe that fashion is more than just clothing and shoes; it is a way to express your personality, confidence, and unique style.\n\nLocated in **Kigali Downtown**, we are dedicated to offering stylish shoes and fashionable clothing for men and women. Our goal is to help every customer find products that match their taste, lifestyle, and everyday needs.\n\nFrom casual wear to elegant styles, we aim to make shopping simple, convenient, and enjoyable. With our online shopping platform, you can explore our collection and discover styles that suit you.\n\n**Our Mission:** To provide fashionable shoes and clothing while delivering a convenient and satisfying shopping experience.\n\n**Our Vision:** To become a trusted fashion destination in Kigali and everywhere you are around the world \n\n**Our Promise:** Quality style, great customer service, and fashion for everyone.\n\n**FRANCOIS onl', '2026-10-31 16:36:25'),
(28, 'about_delivery', 'delivery', '2026-10-31 16:36:25'),
(29, 'about_contact', '0784292599', '2026-10-31 16:36:25'),
(41, 'about_location', 'Kigali, Downtown', '2026-10-31 16:36:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `uq_admin_email` (`email`),
  ADD UNIQUE KEY `uq_admin_phone` (`phone`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip` (`ip`,`ts`),
  ADD KEY `username` (`username`,`ts`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`,`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pay_status` (`pay_status`);

--
-- Indexes for table `otp_codes`
--
ALTER TABLE `otp_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`,`used`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`,`used`),
  ADD KEY `token_hash` (`token_hash`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`,`id`),
  ADD KEY `active_2` (`active`,`cat`,`id`),
  ADD KEY `price` (`price`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `otp_codes`
--
ALTER TABLE `otp_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `otp_codes`
--
ALTER TABLE `otp_codes`
  ADD CONSTRAINT `fk_otp_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `fk_reset_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
